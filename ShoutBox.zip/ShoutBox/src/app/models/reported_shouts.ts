export class ReportedShouts {
  ReportedId!: number;
  ShoutsId!: number;
  UserId!: number;
  ReportedDate!: string;
  IsDeleted!: boolean;
}
