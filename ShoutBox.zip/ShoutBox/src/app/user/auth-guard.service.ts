import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';

@Injectable()
export class AuthGuardService implements CanActivate {
  constructor(public router: Router) {}
  canActivate(): boolean {
    let token = sessionStorage.getItem('jwt');
    console.log(token);
    if (token) {
      console.log('true');
      return true;
    }
    console.log('authguard');
    this.router.navigate(['/login']);
    return false;
  }
}
