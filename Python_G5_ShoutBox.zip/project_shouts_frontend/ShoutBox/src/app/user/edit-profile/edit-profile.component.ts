import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/models/user';
import { UserService } from 'src/app/user.service';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.scss'],
})
export class EditProfileComponent implements OnInit {
  user: User = new User();
  DateOfBirth!: any;
  public entries: any;
  private pranita!: string;
  emailpattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$';
  firstnamepattern = '^[a-zA-Zd._ ]{2,50}$';
  lastnamepattern = '^[a-zA-Zd._ ]{2,50}$';
  phone = '^((\\+91-?))?[0-9]{10}$';
  profilePhoto: any;

  constructor(
    private userService: UserService,
    private http: HttpClient,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.entries = [];
  }

  public ngOnInit() {
    this.getUser();
  }

  getUser() {
    this.userService.getUser().subscribe((data: any) => {
      console.log(data);
      this.user = data;
      this.profilePhoto = data.ProfilePicURL;
    });
  }
  logoutUser() {
    this.userService.logoutUser(this.user).subscribe((data: any) => {
      console.log(data);
      this.router.navigate(['/login']);
    });
  }
  updateUser() {
    console.log(this.user.UserName);
    this.userService
      .updateUser(this.user.UserId, this.user)
      .subscribe((data: any) => {
        alert('User Data Updated !!!');
      });
  }

  onChange(event: any) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.profilePhoto = file;
    }
  }

  uploadProfilePhoto() {
    const formData = new FormData();
    console.log(this.profilePhoto);
    formData.append('ProfilePicURL', this.profilePhoto);
    console.log(formData);

    this.userService.uploadProfilePhoto(formData).subscribe((res: any) => {
      // this.userService.getProfilePhoto().subscribe((res: any) => {
      //   console.log(res);
      //   console.log('after upload profile photo');
      //   this.profilePhoto = res.ProfilePicURL;
      //   console.log(this.profilePhoto);
      // });
      this.getUser();
    });
  }
}
