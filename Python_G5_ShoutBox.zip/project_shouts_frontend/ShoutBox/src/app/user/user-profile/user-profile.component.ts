import { isNgTemplate } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { CommentsService } from 'src/app/comments.service';
import { FriendsService } from 'src/app/friends.service';
import { Comments } from 'src/app/models/comments';
import { Friends } from 'src/app/models/friends';
import { Shouts } from 'src/app/models/shouts';
import { User } from 'src/app/models/user';
import { ShoutsService } from 'src/app/shouts.service';
import { UserService } from 'src/app/user.service';
import { PaginatePipe } from 'ngx-pagination';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss'],
})
export class UserProfileComponent implements OnInit {
  user: User = new User();
  friends: Friends[] = [];
  sentRequest: Friends[] = [];
  shouts: Shouts[] = [];
  user_comments: Comments[] = [];
  shoutIdList: number[] = [];
  requests: Friends[] = [];
  user_comments_set: any;
  p: number = 1;
  friendlist = false;
  shoutlist = false;
  sentRequests = false;
  allRequests = false;
  constructor(
    private friendService: FriendsService,
    private userService: UserService,
    private shoutService: ShoutsService,
    private commentService: CommentsService,
    private router : Router

  ) {}

  ngOnInit(): void {
    this.getUser();
  }

  GetAllFriends() {
    this.friendlist = true;
    this.sentRequests = false;
    this.shoutlist = false;
    this.allRequests = false;
    this.friendService
      .GetAllFriends(this.user.UserId)
      .subscribe((data: any) => {
        this.friends = data;
      });
  }

  GetAllShouts() {
    this.shoutlist = true;
    this.sentRequests = false;
    this.friendlist = false;
    this.allRequests = false;
    this.shoutService.GetShouts(this.user.UserId).subscribe((data: any) => {
      this.shouts = data;
      for (let i of data) {
        this.shoutIdList.push(i.ShoutsId);
      }
      if (this.user.UserId != null) {
        this.commentService
          .getComments(this.shoutIdList, this.user.UserId)
          .subscribe((res: any) => {
            this.user_comments = res;
            for (let i = 0; i < this.user_comments.length; i++) {
              for (let j = 1; j < this.user_comments.length; j++) {
                if (
                  this.user_comments[i].CommentId ==
                  this.user_comments[j].CommentId
                ) {
                  this.user_comments.splice(i, 1);
                }
              }
            }
          });
      }
    });
  }

  getUser() {
    this.userService.getUser().subscribe((data: any) => {
      this.user = data;
      this.GetAllFriends();
    });
  }

  UpdateFriendRequest(FriendId: any, StatusCode: any) {
    this.friendService
      .UpdateFriendRequest(this.user.UserId, FriendId, StatusCode)
      .subscribe((data: any) => {
        if (StatusCode == 0) {
          this.friends.length = 0;
          this.requests.length = 0;
          this.sentRequest.length = 0;
          this.GetAllFriends();
        } else if (StatusCode == 1) {
          this.friends.length = 0;
          this.requests.length = 0;
          this.sentRequest.length = 0;
          this.GetAllFriends();
        } else if (StatusCode == 2) {
          this.friends.length = 0;
          this.requests.length = 0;
          this.sentRequest.length = 0;
          this.GetSentRequest();
        } else if (StatusCode == 3) {
          this.friends.length = 0;
          this.requests.length = 0;
          this.sentRequest.length = 0;
          this.GetAllRequests();
        }
      });
  }

  GetSentRequest() {
    this.sentRequests = true;
    this.friendlist = false;
    this.shoutlist = false;
    this.allRequests = false;
    this.friendService
      .GetSentRequest(this.user.UserId)
      .subscribe((data: any) => {
        this.sentRequest.length = 0;
        data.forEach((item: Friends) => {
          if (item.StatusCode == 5) {
            this.sentRequest.push(item);
          }
        });
      });
  }
  logoutUser() {
    this.userService.logoutUser(this.user).subscribe((data: any) => {
      sessionStorage.clear();
      this.router.navigate(['/login']);
    });
  }

  GetAllRequests() {
    this.allRequests = true;
    this.sentRequests = false;
    this.friendlist = false;
    this.shoutlist = false;
    this.friendService
      .GetAllRequests(this.user.UserId)
      .subscribe((data: any) => {
        this.requests.length = 0;
        data.forEach((item: Friends) => {
          if (item.StatusCode == 4 || item.StatusCode == 5)
          {
            if(item.ActionUserId != this.user.UserId)
            {
              this.requests.push(item);
              
            }

           
          }
        });
      });
  }
}
