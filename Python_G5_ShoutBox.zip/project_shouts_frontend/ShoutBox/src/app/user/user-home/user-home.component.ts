import { Comments } from 'src/app/models/comments';
import { CommentsService } from './../../comments.service';
import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Shouts } from 'src/app/models/shouts';
import { ShoutsService } from 'src/app/shouts.service';
import { UserService } from 'src/app/user.service';
import { UserTimeline } from 'src/app/models/user_timeline';
import { User } from 'src/app/models/user';
import { Router } from '@angular/router';
import { Friends } from 'src/app/models/friends';
import { FriendsService } from 'src/app/friends.service';

@Component({
  selector: 'app-user-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.scss'],
})
export class UserHomeComponent implements OnInit {
  user: User = new User();
  DateCreated!: any;

  user_shouts: UserTimeline[] = [];
  user_comments: Comments[] = [];
  text: any;
  fileData: any;
  CommentContent: any;
  ShoutsId: any;
  shoutIdList: number[] = [];
  numberList: number[] = [1];
  friends: Friends[] = [];
  searchValue!: string;
  p: number = 1;
  UserId = sessionStorage.getItem('UserId');

  constructor(
    private userService: UserService,
    private commentsService: CommentsService,
    private router: Router,
    private friendService: FriendsService
  ) {}
  ngOnInit() {
    this.getUser();
    this.userService.getShouts().subscribe((res: any) => {
      this.user_shouts = res;
      for (let i of res) {
        this.shoutIdList.push(i.ShoutsId);
      }
      if (this.UserId != null && this.shoutIdList) {
        this.commentsService
          .getComments(this.shoutIdList, this.UserId)
          .subscribe((res: any) => {
            this.user_comments = res;
          });
      }
    });
  }

  getUser() {
    this.userService.getUser().subscribe((data: any) => {
      this.user = data;
    });
  }
  logoutUser() {
    this.userService.logoutUser(this.user).subscribe((data: any) => {
      sessionStorage.clear();
      this.router.navigate(['/login']);
    });
  }

  onChange(event: any) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.fileData = file;
    }
  }
  shoutId(id: any) {
    this.ShoutsId = id;
    const formData = new FormData();
    formData.append('ShoutsId', this.ShoutsId);
    formData.append('CommentContent', this.CommentContent);
    this.CommentContent = '';
    if (this.UserId != null) formData.append('UserId', this.UserId);
    this.commentsService.AddComment(formData).subscribe((res: any) => {
      this.shoutIdList.length = 0;
      for (let i of this.user_shouts) {
        this.shoutIdList.push(i.ShoutsId);
      }
      if (this.UserId != null)
        this.commentsService
          .getComments(this.shoutIdList, this.UserId)
          .subscribe((res: any) => {
            this.user_comments.length = 0;
            this.user_comments = res;
          });
    });
  }

  onSubmit() {
    const formData = new FormData();

    let userid = sessionStorage.getItem('UserId');
    if (userid != null) {
      if (this.fileData) {
        let element = new String(this.fileData.type);
        let FileType = '';
        for (let index = 0; index < element.length; index++) {
          if (element[index] == '/') {
            break;
          } else FileType = FileType + element[index];
        }
        formData.append('TextContent', this.text);
        formData.append('File', this.fileData);
        formData.append('FileType', FileType);
        formData.append('UserId', userid);
      } else {
        formData.append('TextContent', this.text);
        formData.append('UserId', userid);
      }
    }
    this.userService.shoutUpload(formData).subscribe((res: any) => {
      this.userService.getShouts().subscribe((res: any) => {
        this.user_shouts.length = 0;
        this.user_shouts = res;
      });
    });
  }

  searchUser() {
    if (this.searchValue) {
      this.friendService
        .searchUser(this.user.UserId, this.searchValue)
        .subscribe((data: any) => {
          this.friends = data;
        });
    } else {
      this.friends.length = 0;
    }
  }

  UpdateFriendRequest(FriendId: any, StatusCode: any) {
    this.friendService
      .UpdateFriendRequest(this.user.UserId, FriendId, StatusCode)
      .subscribe((data: any) => {
        this.searchUser();
        // delete this.friends[FriendId];
      });
  }

  SendFriendRequest(FriendId: any) {
    this.friendService
      .SendFriendRequest(this.user.UserId, FriendId)
      .subscribe((data: any) => {
        this.searchUser();
        // delete this.friends[FriendId];
      });
  }
}
