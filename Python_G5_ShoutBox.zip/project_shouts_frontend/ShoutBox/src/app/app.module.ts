import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserService } from './user.service';
import { UserModule } from './user/user.module';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { RouterModule } from '@angular/router';
import { DatePipe } from '@angular/common';
import { JwtModule, JWT_OPTIONS } from '@auth0/angular-jwt';
import { CookieService } from 'ngx-cookie-service';
import { AuthGuardService } from './user/auth-guard.service';
import {
  JwPaginationComponent,
  JwPaginationModule,
} from 'jw-angular-pagination';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  declarations: [AppComponent, HomeComponent],
  imports: [
    NgxPaginationModule,
    BrowserModule,
    AppRoutingModule,
    UserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,

    RouterModule,
  ],
  providers: [UserService, DatePipe, CookieService, AuthGuardService],
  bootstrap: [AppComponent],
})
export class AppModule {}
