from django.contrib import admin
from django.contrib.auth.models import Group
from django.urls import path
from django.http import HttpResponseRedirect
from django.utils.html import format_html
# Register your models here.

from .models import Comments, Friends, ReportedShouts, Shouts, Users


admin.site.site_header = "Admin DashBoad"
admin.site.site_title = "ShoutBox"
admin.site.index_title = ''

class UserAdmin(admin.ModelAdmin):
    sortable_by = 'UserId'
    search_fields = ['UserName','FirstName','LastName','Email']
    list_display = ('UserId','image_tag','UserName','FirstName','LastName','Email','MobileNo','Password','DateOfBirth')
    list_display_links = ('UserName',)


class ShoutAdmin(admin.ModelAdmin):
    sortable_by = 'ShoutsId'
    search_fields = ['ShoutsId','UserId','TextContent']
    list_display = ('ShoutsId','UserId','TextContent','DateCreated','File','FileType')
    list_display_links = ('ShoutsId','TextContent')


admin.site.register(Users,UserAdmin)
admin.site.register(Comments)
admin.site.register(Friends)
admin.site.register(ReportedShouts)
admin.site.register(Shouts,ShoutAdmin)
