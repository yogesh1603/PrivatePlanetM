// $(document).ready(function () {
//   const urlparams = new URLSearchParams(window.location.search);
//   var str = urlparams.get("id");
//   // console.log(str);
//   var albums = "";
//   var artist = "";
//   albums += '<a href="./Album.html?id=' + str + '">Albums</a>';
//   artist += '<a href="./Music-Library-Page.html?id=' + str + '">Artists</a>';
//   $("#albumPage").append(albums);
//   $("#artistPage").append(artist);

//   $.getJSON("http://localhost:3000/Album", function (data) {
//     var Albums = "";

//     $.each(data, function (key, value) {
//       if (str == value.lang) {
//         Albums += '<div class="col">';

//         Albums += '<div class="card">';

//         Albums +=
//           '<img class="card-img-top" src="' +
//           value.img +
//           '" alt="Album"></img>';

//         Albums += '<div class="card-body">';

//         Albums +=
//           '<h1 class="card-title">' +
//           '<a href="AlbumSongs.html?id=' +
//           value.AlbumName +
//           ' ">' +
//           value.AlbumName +
//           "</a>" +
//           "</h1>";

//         Albums +=
//           '<h1 classs="card-title">Songs: ' + value.AlbumSongs + "</h1>";

//         Albums += "</div>";

//         Albums += "</div>";

//         Albums += "</div>";
//       }
//     });

//     $("#table").append(Albums);
//   });
// });

window.onload = function () {
  const charactersList = document.getElementById("charactersList");
  const searchBar = document.getElementById("searchBar");
  const user = document.getElementById("user");
  let hpCharacters = [];

  const urlparams = new URLSearchParams(window.location.search);
  var str = urlparams.get("id");

  searchBar.addEventListener("keyup", (e) => {
    const searchString = e.target.value.toLowerCase();

    const filteredCharacters = hpCharacters.filter((character) => {
      return (
        character.AlbumName.toLowerCase().includes(searchString) ||
        character.lang.toLowerCase().includes(searchString)
      );
    });
    displayCharacters(filteredCharacters);
  });

  const loadCharacters = async () => {
    try {
      const res = await fetch("http://localhost:3000/Album");
      hpCharacters = await res.json();

      console.log(hpCharacters);
      var result = findSong(hpCharacters, str);
      console.log(result);
      hpCharacters = result;

      displayCharacters(result);
    } catch (err) {
      console.error(err);
    }
  };
  const displayCharacters = (characters) => {
    const htmlString = characters
      .map((value) => {
        return `<div class="col">

                <div class="card">
        
                  '<img class="card-img-top" src="
                  ${value.img}" alt="Album"></img>
                  <div class="card-body">
                  <h1 class="card-title">

                  <a href="AlbumSongs.html?id=${value.AlbumName}">
                  ${value.AlbumName}</a> 
                  </h1>
                  <h1 classs="card-title">Songs: ${value.AlbumSongs}</h1>
        
             </div>
             </div>
             </div>
        
        
        `;
      })
      .join("");
    charactersList.innerHTML = htmlString;
  };

  loadCharacters();

  function findId(data, id) {
    var categoryArray = data.Album;
    for (var i = 0; i < categoryArray.length; i++) {
      if (categoryArray[i].lang == id) {
        return categoryArray[i];
      }
    }
  }
  function findSong(data, id) {
    var result = [];
    console.log(id);
    for (var i = 0; i < data.length; i++) {
      if (data[i].lang == id) {
        result.push(data[i]);
      }
    }
    return result;
  }
};
