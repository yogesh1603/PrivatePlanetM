$(document).ready(function () {
  const urlparams = new URLSearchParams(window.location.search);
  var ArtistName = urlparams.get("id");
  console.log(ArtistName);

  var url = "http://localhost:3000/Album";

  $.getJSON(url, function (data) {
    var ArtistSong = "";
    console.log(data);
    /*var albumid=document.getElementById("albumNm").value;*/

    $.each(data, function (key, value) {
      console.log(value);

      for (var i = 0; i < value.songs.length; i++) {
        if (value.songs[i].ArtistName == ArtistName) {
          ArtistSong += "<tr>";

          ArtistSong +=
            "<td>" +
            '<a href="../html/music-panel.html?id=' +
            value.songs[i].ArtistName +
            "&songName=" +
            value.songs[i].SongName +
            '">' +
            value.songs[i].SongName +
            "</a>" +
            "</td>";

          ArtistSong += "<td>" + value.songs[i].ArtistName + "</td>";

          ArtistSong += "</tr>";
        }
      }
    });

    $("#table").append(ArtistSong);
  });
});
