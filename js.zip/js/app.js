const charactersList = document.getElementById("charactersList");
const searchBar = document.getElementById("searchBar");
const user = document.getElementById("user");
let hpCharacters = [];

searchBar.addEventListener("keyup", (e) => {
  const searchString = e.target.value.toLowerCase();

  const filteredCharacters = hpCharacters.filter((character) => {
    return (
      character.song.toLowerCase().includes(searchString) ||
      character.movie.toLowerCase().includes(searchString)
    );
  });
  displayCharacters(filteredCharacters);
});

// const loadCharacters = async () => {
//     try {
//         // const res = await fetch("../music.json");
//         hpCharacters = await res.json();
//         console.log(hpCharacters)
//         displayCharacters(hpCharacters);
//     } catch (err) {
//         console.error(err);
//     }
// };

const displayCharacters = (characters) => {
  const htmlString = characters
    .map((character) => {
      return `
            <li class="character" id ="${character.category}">
                <h2>Movie:${character.movie}</h2>
                <p>song: ${character.song}</p>
            </li>
        `;
    })
    .join("");
  charactersList.innerHTML = htmlString;
};

// loadCharacters();

$(function () {
  $("#sidebarCollapse").on("click", function () {
    $("#sidebar, #content").toggleClass("active");
  });
});

function userName() {
  user.innerHTML = "Welcome, " + localStorage.getItem("userDetails");
}
userName();
