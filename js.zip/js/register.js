$(document).ready(function() {

    var userName=1;
    var password="";
    var confirmPassword="";
    var email ="";
    var phone=1234567890;
    var isRegistered=false;
    $("#Register").click(function() {
        userName = $("#userName").val();
        email = $("#email").val();
        password = $("#password").val();
        confirmPassword = $("#confirm-password").val();
        phone= $("#phone").val();
        
        if(userName=="" && email=="" && userName.length < 5 && email.length < 5){
            window.alert("please enter valid username & email.");
            document.getElementById("userName").focus();
            return false;
        }
        if((phone.length) < 10){
            window.alert("please enter valid phone number.");
            document.getElementById("phone").focus();
            return false;
        }
        else if((password.length) < 8 ){
        window.alert("Password length must be greater than 8");
        document.getElementById("password").focus();
        return false;
        }
        else if(password != confirmPassword){
        window.alert("password & confirm password should be same");
        document.getElementById("password").focus();
        document.getElementById("confirm-password").focus();
        return false;
        }
        else{
            adduser();
            isRegistered=true;
            alert("Registered!!!!");
        }

        // if(isRegistered){
        //     window.location.href="./login.html";
        // }
     });
 
    
    //  add user function starts
    function adduser(){
        console.log("hey");
        $.getJSON("http://localhost:3000/users",function(data){
        console.log("hey");
        console.log(data.length);
        id=data.length+1;

        var newuser = {
            "id":id,
            "username":userName,
            "email":email,
            "phone":phone,
            "password":password,
            "cpassword":confirmPassword
        };

        data.push(newuser);
 
        $.ajax
        ({
            type: "POST",
            dataType : 'json',
            async: false,
            url: 'http://localhost:3000/users',
            data:  newuser ,
            success: function () {alert("Thanks!"); },
            failure: function() {alert("Error!");}
        });
        });
    }

    // add user function ends
});