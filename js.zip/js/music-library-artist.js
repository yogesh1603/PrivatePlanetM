// $(document).ready(function () {
//   const urlparams = new URLSearchParams(window.location.search);
//   var str = urlparams.get("id");
//   // console.log(str);
//   var albums = "";
//   var artist = "";
//   albums += '<a href="./Album.html?id=' + str + '">Albums</a>';
//   artist += '<a href="./Music-Library-Page.html?id=' + str + '">Artists</a>';
//   $("#albumPage").append(albums);
//   $("#artistPage").append(artist);
//   var result;
//   const url = "http://localhost:3000/Album?lang=" + str;
//   $.getJSON(url, function (data) {
//     var lan = "";
//     $.each(data, function (key, value) {
//       for (var i = 0; i < value.songs.length; i++) {
//         lan += '<div class="col">';
//         lan += '<div class="card">';
//         lan += '<img class="card-img-top" src="' + value.songs[i].img + '" >';
//         lan += '<div class="card-body">';
//         // lan += '<td>' + value.lang + '</td>';

//         lan +=
//           '<h5 class="card-title text-center">' +
//           '<a href="../html/ArtistsSongs.html?id=' +
//           value.songs[i].ArtistName +
//           '">' +
//           value.songs[i].ArtistName +
//           "</a>" +
//           "</h5>";

//         //   lan += '<td>' + value.songs[i].songName+ '</td>';
//         lan += "</div>";
//         lan += "</div>";
//         lan += "</div>";
//       }
//     });

//     //INSERTING ROWS INTO TABLE
//     $("#table").append(lan);
//   });
// });

window.onload = function () {
  const charactersList = document.getElementById("charactersList");
  const searchBar = document.getElementById("searchBar");
  const user = document.getElementById("user");
  let hpCharacters = [];

  const urlparams = new URLSearchParams(window.location.search);
  var str = urlparams.get("id");

  searchBar.addEventListener("keyup", (e) => {
    const searchString = e.target.value.toLowerCase();

    const filteredCharacters = hpCharacters.filter((character) => {
      return (
        character.ArtistName.toLowerCase().includes(searchString) ||
        character.ArtistName.toLowerCase().includes(searchString)
      );
    });
    displayCharacters(filteredCharacters);
  });

  const loadCharacters = async () => {
    try {
      const res = await fetch("http://localhost:3000/Album");
      hpCharacters = await res.json();

      console.log(hpCharacters);
      var result = findSong(hpCharacters, str);
      console.log(result);
      var id = findId(result);
      console.log(id);
      hpCharacters = id;

      displayCharacters(id);
    } catch (err) {
      console.error(err);
    }
  };
  const displayCharacters = (characters) => {
    const htmlString = characters
      .map((value) => {
        return ` <div class="col">
        <div class="card">
        <img class="card-img-top" src="${value.img}" >
        <div class="card-body">
          <h5 class="card-title text-center">
          <a href="../html/ArtistsSongs.html?id=${value.ArtistName}">
          ${value.ArtistName}
          </a>
          </h5>
        </div>
        </div>
        </div>

        `;
      })
      .join("");
    charactersList.innerHTML = htmlString;
  };

  loadCharacters();

  function findId(data) {
    var artist = [];
    for (var i = 0; i < data.length; i++) {
      for (var j = 0; j < data[i].length; j++) {
        artist.push(data[i][j]);
      }
    }
    return artist;
  }
  function findSong(data, id) {
    var result = [];
    for (var i = 0; i < data.length; i++) {
      if (data[i].lang == id) {
        result.push(data[i].songs);
      }
    }
    return result;
  }
};
