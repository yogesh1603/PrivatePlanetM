$(document).ready(function () {
  const urlparams = new URLSearchParams(window.location.search);
  var AlbumName = urlparams.get("id");
  console.log(AlbumName);

  var url = "http://localhost:3000/Album?AlbumName=" + AlbumName;

  $.getJSON(url, function (data) {
    var AlbumSong = "";
    console.log(data);

    $.each(data, function (key, value) {
      console.log(value);

      for (var i = 0; i < value.songs.length; i++) {
        AlbumSong += "<tr>";

        AlbumSong +=
          "<td>" +
          '<a href="../html/music-panel.html?id=' +
          value.AlbumName +
          "&songName=" +
          value.songs[i].SongName +
          '">' +
          value.songs[i].SongName +
          "</a>" +
          "</td>";

        AlbumSong += "<td>" + value.songs[i].ArtistName + "</td>";

        AlbumSong += "</tr>";
      }
    });

    $("#table").append(AlbumSong);
  });
});
