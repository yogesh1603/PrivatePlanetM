window.onload = function () {
  var usera = localStorage.getItem("userDetails");
  console.log(usera);
  usera = usera + "Favorite";
  var a = localStorage.getItem(usera);
  var retrive = JSON.parse(a);

  console.log(retrive);
  const favoriteSong = document.getElementById("favoriteSong");
  const searchBar = document.getElementById("searchBar");
  const user = document.getElementById("user");
  let hpCharacters = [];

  const urlparams = new URLSearchParams(window.location.search);
  var str = urlparams.get("id");

  //   searchBar.addEventListener("keyup", (e) => {
  //     const searchString = e.target.value.toLowerCase();

  //     const filteredCharacters = hpCharacters.filter((character) => {
  //       return (
  //         character.ArtistName.toLowerCase().includes(searchString) ||
  //         character.ArtistName.toLowerCase().includes(searchString)
  //       );
  //     });
  //     displayCharacters(filteredCharacters);
  //   });

  const loadCharacters = async () => {
    try {
      const res = await fetch("http://localhost:3000/Album");
      hpCharacters = await res.json();
      console.log(hpCharacters);
      var result = findSong(hpCharacters);
      console.log(result);
      result = findRecentlyPlayedSong(result);
      //   console.log(result);
      //   var id = findId(result);
      //   var song = recentlyAdded(id);
      //   console.log(id);
      //   hpCharacters = id;

      displayCharacters(result);
    } catch (err) {
      console.error(err);
    }
  };
  const displayCharacters = (characters) => {
    const htmlString = characters
      .map((value) => {
        console.log(value);
        return ` <div class="col">
              <div class="card">
              <img class="card-img-top" src="${value.img}" >
              <div class="card-body">
                <h5 class="card-title text-center">
                <a href="../html/ArtistsSongs.html?id=${value.ArtistName}">
                ${value.SongName}
                </a>
                </h5>
              </div>
              </div>
              </div>
      
              `;
      })
      .join("");
    favoriteSong.innerHTML = htmlString;
  };

  loadCharacters();

  function findId(data) {
    var artist = [];
    for (var i = 0; i < data.length; i++) {
      for (var j = 0; j < data[i].length; j++) {
        artist.push(data[i][j]);
      }
    }
    return artist;
  }
  function findSong(data) {
    var result = [];
    for (var i = 0; i < data.length; i++) result.push(data[i].songs);
    return result;
  }

  //   function recentlyAdded(data) {
  //     var recentlyAdded = [];
  //     console.log(data);
  //     var date = new Date();
  //     var day = date.getDate();
  //     var month = date.getMonth() + 1;
  //     console.log(month);
  //     var year = date.getFullYear();
  //     var today = day + "/" + month + "/" + year;
  //     console.log(today);
  //     for (var i = 0; i < data.length; i++) {
  //       var a = data[i].Date;
  //       recentlyAdded.push(a.split("/"));
  //     }
  //     console.log(recentlyAdded);
  //     var songNumber = [];
  //     for (var i = 0; i < recentlyAdded.length; i++) {
  //       for (var j = 0; j < recentlyAdded[i].length; j++)
  //         if (j == 1) {
  //           console.log(j);
  //           console.log(parseInt(recentlyAdded[i][j]));
  //           if (parseInt(recentlyAdded[i][j]) == month - 1) {
  //             console.log("hi");
  //             songNumber.push(i);
  //           }
  //         }
  //     }
  //     var result = [];
  //     for (var i = 0; i < songNumber.length; i++) {
  //       for (var j = 0; j < data.length; j++) {
  //         if (songNumber[i] == j) {
  //           result.push(data[j]);
  //         }
  //       }
  //     }
  //     console.log(result);
  //     return result;
  //   }
  //   recentlyAdded();

  function findRecentlyPlayedSong(data) {
    console.log(data);
    var result = [];
    for (var k = 0; k < retrive.length; k++) {
      for (var i = 0; i < data.length; i++) {
        for (var j = 0; j < data[i].length; j++) {
          if (data[i][j].SongName == retrive[k]) {
            result.push(data[i][j]);
          }
        }
      }
    }
    console.log(result);
    return result;
  }
};
