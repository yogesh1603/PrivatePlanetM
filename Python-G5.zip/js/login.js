$(document).ready(function () {
  var username = 1;
  var password = "";
  var isRegistered = false;
  var userDetails;

  $("#login").click(function () {
    username = $("#username").val();
    password = $("#password").val();

    console.log(username + " " + password);

    $.getJSON("http://localhost:3000/users", function (data) {
      console.log(data);
      $.each(data, function (key, value) {
        console.log(value.username + " " + value.password);
        if (username == value.username && password == value.password) {
          isRegistered = true;
          userDetails = value;
        }
      });

      if (!isRegistered) {
        alert("Please enter valid username & password");
        return false;
      } else {
        alert("Login Successfull");
        window.location.href = "./language_select.html";
        localStorage.setItem("userDetails", userDetails.username);
        return false;
      }
    });
  });
});
