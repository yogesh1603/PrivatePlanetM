$(document).ready(function () {
  const urlparams = new URLSearchParams(window.location.search);
  var str = urlparams.get("id");
  // console.log(str);
  var albums = "";
  var artist = "";
  albums += '<a href="./Album.html?id=' + str + '">Albums</a>';
  artist += '<a href="./Music-Library-Page.html?id=' + str + '">Artists</a>';
  $("#albumPage").append(albums);
  $("#artistPage").append(artist);

  $.getJSON("http://localhost:3000/Album", function (data) {
    var Albums = "";

    $.each(data, function (key, value) {
      if (str == value.lang) {
        Albums += '<div class="col">';

        Albums += '<div class="card">';

        Albums +=
          '<img class="card-img-top" src="' +
          value.img +
          '" alt="Album"></img>';

        Albums += '<div class="card-body">';

        Albums +=
          '<h1 class="card-title">' +
          '<a href="AlbumSongs.html?id=' +
          value.AlbumName +
          ' ">' +
          value.AlbumName +
          "</a>" +
          "</h1>";

        Albums +=
          '<h1 classs="card-title">Songs: ' + value.AlbumSongs + "</h1>";

        Albums += "</div>";

        Albums += "</div>";

        Albums += "</div>";
      }
    });

    $("#table").append(Albums);
  });
});
