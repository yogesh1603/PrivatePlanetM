function getForm(){
    window.location.href = '/login.html';
}


var x = document.getElementById("myAudio");
var icon = document.getElementById("play-icon");

function playAudio(){
    if(x.paused){
        x.play();
        icon.src = "../images/pause.png";
    }else{
        x.pause();
        icon.src = "../images/play.png";
    }
}