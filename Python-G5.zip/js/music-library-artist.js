$(document).ready(function () {
  const urlparams = new URLSearchParams(window.location.search);
  var str = urlparams.get("id");
  // console.log(str);
  var albums = "";
  var artist = "";
  albums += '<a href="./Album.html?id=' + str + '">Albums</a>';
  artist += '<a href="./Music-Library-Page.html?id=' + str + '">Artists</a>';
  $("#albumPage").append(albums);
  $("#artistPage").append(artist);
  var result;
  const url = "http://localhost:3000/Album?lang=" + str;
  $.getJSON(url, function (data) {
    var lan = "";
    $.each(data, function (key, value) {
      for (var i = 0; i < value.songs.length; i++) {
        lan += '<div class="col">';
        lan += '<div class="card">';
        lan += '<img class="card-img-top" src="' + value.songs[i].img + '" >';
        lan += '<div class="card-body">';
        // lan += '<td>' + value.lang + '</td>';

        lan +=
          '<h5 class="card-title text-center">' +
          '<a href="../html/ArtistsSongs.html?id=' +
          value.songs[i].ArtistName +
          '">' +
          value.songs[i].ArtistName +
          "</a>" +
          "</h5>";

        //   lan += '<td>' + value.songs[i].songName+ '</td>';
        lan += "</div>";
        lan += "</div>";
        lan += "</div>";
      }
    });

    //INSERTING ROWS INTO TABLE
    $("#table").append(lan);
  });
});
